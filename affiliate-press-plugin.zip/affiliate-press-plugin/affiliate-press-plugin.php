<?php
/**
 * Plugin Name: Affiliate Press Plugin 
 * Description: Plugin para exibir quantas vendas foram feitas por cupom de desconto, e gerar relatórios individuais por parceiro.
 * Version: 0.0.1
 * Author: João Saraiva // jsaraivx
 * Author URI: http://github.com/jsaraivx
 * License: Commercial use.
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Função para exibir o relatório de cupons por parceiro
function custom_woocommerce_coupon_partner_report( $atts ) {
	if ( ! isset( $_GET['coupon'] ) ) {
		return 'Cupom não especificado.';
	}

	$coupon_code = sanitize_text_field( $_GET['coupon'] );
	$args = array(
		'status' => array('wc-completed', 'wc-processing'),
		'limit' => -1, // sem limite de pedidos
	);
	$orders = wc_get_orders( $args );

	$coupon_counts = 0;
	$product_names = array();

	foreach ( $orders as $order ) {
		$used_coupons = $order->get_used_coupons();

		if ( in_array( $coupon_code, $used_coupons ) ) {
			$coupon_counts++;
			foreach ( $order->get_items() as $item ) {
				$product = $item->get_product();
				$product_names[] = $product ? $product->get_name() : '';
			}
		}
	}

	// Exibe o relatório
	$output = '<h2>Relatório de Vendas por Cupom</h2>';
	$output .= '<p><strong>Cupom:</strong> ' . esc_html( $coupon_code ) . '</p>';
	$output .= '<p><strong>Vendas:</strong> ' . esc_html( $coupon_counts ) . '</p>';
	$output .= '<p><strong>Produtos Vendidos:</strong></p>';
	$output .= '<ul>';
	foreach ( $product_names as $product_name ) {
		$output .= '<li>' . esc_html( $product_name ) . '</li>';
	}
	$output .= '</ul>';

	return $output;
}
add_shortcode( 'partner_coupon_report', 'custom_woocommerce_coupon_partner_report' );

// Função para criar links específicos para parceiros
function custom_woocommerce_create_partner_links() {
	$partners = array(
		'Douglas' => 'douglas10',
		'Parceiro2' => 'parceiro210',
		// Adicione outros parceiros e cupons aqui
	);

	echo '<h2>Links de Relatórios para Parceiros</h2>';
	echo '<ul>';
	foreach ( $partners as $partner_name => $coupon_code ) {
		$link = home_url( '/relatorio-parceiro/?coupon=' . urlencode( $coupon_code ) );
		echo '<li><a href="' . esc_url( $link ) . '">' . esc_html( $partner_name ) . '</a></li>';
	}
	echo '</ul>';
}

// Adiciona a página de links ao menu do admin
function custom_woocommerce_add_links_menu() {
	add_menu_page(
		'Links de Relatórios', // Título da página
		'Links de Relatórios', // Título do menu
		'manage_options', // Capacidade
		'partner-links', // Slug do menu
		'custom_woocommerce_create_partner_links' // Função de callback
	);
}
add_action( 'admin_menu', 'custom_woocommerce_add_links_menu' );